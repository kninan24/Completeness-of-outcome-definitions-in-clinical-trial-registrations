# Completeness of outcome definitions in clinical trial registrations: a cross-sectional study

## Project Overview
This project examines the completeness of outcome reporting in randomized clinical trials (RCTs) published in ICMJE member journals.

## Files				###Descriptions

codebook.csv				###Variable definitions for trial level data from ClinicalTrials.gov, outcome level data from ClinicalTrials.gov, 							trial level data from other ICMJE recognized registries, and for agreement between human raters 

Trial_Level_Code.sas			###Code used for analysis of trial level data from ClinicalTrials.gov and from other ICMJE recognized registries 
Outcome_Level_Code.sas			###Code used for analysis of outcome level data from ClinicalTrials.gov
human_agree.sas				###Code used for analysis of agreement between human raters
LLM_Performance_Metrics.R		###Code used for analysis of agreement between LLM and human ratings
Bootstrapping_95%_CIs.R			###Code used for bootstrapping 95% CIs
Plots_First_Registration_Study_Start.R	###Code used to generate plots of Timing of First Registration Relative to Study Start


