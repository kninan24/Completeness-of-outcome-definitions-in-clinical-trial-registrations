######################################################################################################
#Title: Completeness of outcome definitions in clinical trial registrations: Plots of Timing of First Registration Relative to Study Start
#Purpose: This file includes the code used to generate both plots of timing of First Registration Relative to Study Start (Appendix 6)
#Date last updated: 12/15/2025
######################################################################################################


###############################
# Setup - Define paths and filenames
###############################
filepath <- "C:/Your/filepath/here"  #replace with your desired filepath to the data file listed below  
data_CTG <- "CTG_Trial_level_data.csv"

###############################
# Load packages
###############################
library(tidyverse)
library(lubridate)
library(scales)
library(gridExtra)

###############################
# Read data
###############################

df <- read_csv(file.path(filepath, data_CTG), show_col_types = FALSE)

###############################
# Figure A: Registration timing using Date First Submitted that Met QC Criteria
###############################
df_figA <- df %>%
  mutate(
    reg_date   = mdy(first_registration_date_clean_01),
    start_date = mdy(trial_start_date_clean_01),
    comp_date  = mdy(primary_completion_date_clean_01),
    
    days_after_start = as.numeric(reg_date - start_date),
    
    prospective_registration   = if_else(reg_date <= start_date, 1L, 0L),
    retrospective_registration = if_else(reg_date >  start_date, 1L, 0L),
    retrospective_within_21_days = if_else(retrospective_registration == 1L & days_after_start <= 21, 1L, 0L),
    retrospective_after_21_days  = if_else(retrospective_registration == 1L & days_after_start >  21, 1L, 0L),
    
    registration_category = case_when(
      prospective_registration == 1L                            ~ "Registered before Study Start Date (Prospective)",
      retrospective_registration == 1L & days_after_start <= 21 ~ "Registered within 21 days of Study Start Date (Retrospective)",
      retrospective_registration == 1L & days_after_start >  21 ~ "Registered after 21 days of Study Start Date (Retrospective)"
    ),
    
    x_plot = days_after_start,
    
    pc_status = if_else(comp_date > as.Date("2025-10-01"),
                        "Ongoing Trial",
                        "Completed Trial")
  ) %>%
  mutate(
    registration_category = factor(
      registration_category,
      levels = c(
        "Registered before Study Start Date (Prospective)",
        "Registered within 21 days of Study Start Date (Retrospective)",
        "Registered after 21 days of Study Start Date (Retrospective)"
      )
    ),
    pc_status = factor(pc_status, levels = c("Completed Trial", "Ongoing Trial"))
  )

pal_fill <- c(
  "Registered before Study Start Date (Prospective)"              = "#2ca02c",
  "Registered within 21 days of Study Start Date (Retrospective)" = "#ffbf00",
  "Registered after 21 days of Study Start Date (Retrospective)"  = "#d62728"
)

left_limit  <- -3 * 365
right_limit <-  1 * 365

breaks_mixed <- c(-365, -730, -1095, -182.5, 180, 365)

mixed_labels <- function(x) {
  sapply(x, function(v) {
    if (v == -182.5) {
      ""
    } else if (v < 0) {
      yrs <- as.integer(abs(v) / 365)
      paste0("-", yrs, " year", ifelse(yrs == 1, "", "s"))
    } else if (v == 180) {
      ""
    } else if (v == 365) {
      "1 year"
    } else {
      paste0(v, " days")
    }
  })
}

pA <- ggplot(df_figA, aes(x = x_plot, y = 0)) +
  geom_vline(xintercept = 0, linewidth = 0.7, color = "grey30") +
  geom_point(
    data = subset(df_figA, pc_status == "Completed Trial"),
    aes(fill = registration_category),
    shape = 21, size = 2.2,
    position = position_jitter(width = 0, height = 0.01),
    stroke = 0
  ) +
  geom_point(
    data = subset(df_figA, pc_status == "Ongoing Trial"),
    aes(fill = registration_category, colour = pc_status),
    shape = 21, size = 2.2,
    position = position_jitter(width = 0, height = 0.01),
    stroke = 0.9
  ) +
  scale_fill_manual(values = pal_fill, name = NULL) +
  scale_color_manual(values = c("Ongoing Trial" = "black"), name = NULL) +
  scale_x_continuous(
    breaks  = c(breaks_mixed, 0),
    labels  = c(mixed_labels(breaks_mixed), "Study Start Date"),
    expand  = expansion(mult = c(0.015, 0.015))
  ) +
  coord_cartesian(xlim = c(left_limit, right_limit), clip = "off") +
  labs(x = "Difference between First Registration that met QC criteria and Study Start Date (in days)", y = NULL) +
  theme_classic(base_size = 12) +
  theme(
    plot.margin  = margin(t = 10, r = 28, b = 12, l = 28),
    axis.text.y  = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid   = element_blank(),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.justification = "center",
    legend.text = element_text(size = 8),
    legend.key.size = unit(0.4, "cm"),
    axis.text.x = element_text(margin = margin(t = 6))
  ) +
  guides(
    fill   = guide_legend(
      order = 1, nrow = 1,
      override.aes = list(colour = NA, stroke = 0)
    ),
    colour = guide_legend(
      order = 2, nrow = 1,
      override.aes = list(fill = "white", stroke = 0.9)
    )
  )

print(pA)

ggsave(file.path(filepath, "FigureA_registration_timing_with_date_first_submitted_meeting_QC.png"),
       pA, width = 10, height = 5, dpi = 300)

###############################
# Figure B: Registration timing using First Submitted Date
###############################

df_figB <- df %>%
  mutate(
    reg_date   = mdy(first_submitted_date),
    start_date = mdy(trial_start_date_clean_01),
    comp_date  = mdy(primary_completion_date_clean_01),
    
    days_after_start = as.numeric(reg_date - start_date),
    
    prospective_registration   = if_else(reg_date <= start_date, 1L, 0L),
    retrospective_registration = if_else(reg_date >  start_date, 1L, 0L),
    retrospective_within_21_days = if_else(retrospective_registration == 1L & days_after_start <= 21, 1L, 0L),
    retrospective_after_21_days  = if_else(retrospective_registration == 1L & days_after_start >  21, 1L, 0L),
    
    registration_category = case_when(
      prospective_registration == 1L                            ~ "Registered before Study Start Date (Prospective)",
      retrospective_registration == 1L & days_after_start <= 21 ~ "Registered within 21 days of Study Start Date (Retrospective)",
      retrospective_registration == 1L & days_after_start >  21 ~ "Registered after 21 days of Study Start Date (Retrospective)"
    ),
    
    x_plot = days_after_start,
    
    pc_status = if_else(comp_date > as.Date("2025-10-01"),
                        "Ongoing Trial", "Completed Trial")
  ) %>%
  mutate(
    registration_category = factor(
      registration_category,
      levels = c(
        "Registered before Study Start Date (Prospective)",
        "Registered within 21 days of Study Start Date (Retrospective)",
        "Registered after 21 days of Study Start Date (Retrospective)"
      )
    ),
    pc_status = factor(pc_status, levels = c("Completed Trial", "Ongoing Trial"))
  )

pB <- ggplot(df_figB, aes(x = x_plot, y = 0)) +
  geom_vline(xintercept = 0, linewidth = 0.7, color = "grey30") +
  geom_point(
    data = subset(df_figB, pc_status == "Completed Trial"),
    aes(fill = registration_category),
    shape = 21, size = 2.2,
    position = position_jitter(width = 0, height = 0.01),
    stroke = 0
  ) +
  geom_point(
    data = subset(df_figB, pc_status == "Ongoing Trial"),
    aes(fill = registration_category, colour = pc_status),
    shape = 21, size = 2.2,
    position = position_jitter(width = 0, height = 0.01),
    stroke = 0.9
  ) +
  scale_fill_manual(values = pal_fill, name = NULL) +
  scale_color_manual(values = c("Ongoing Trial" = "black"), name = NULL) +
  scale_x_continuous(
    breaks  = c(breaks_mixed, 0),
    labels  = c(mixed_labels(breaks_mixed), "Study Start Date"),
    expand  = expansion(mult = c(0.015, 0.015))
  ) +
  coord_cartesian(xlim = c(left_limit, right_limit), clip = "off") +
  labs(
    title = NULL,
    x = "Difference between First Submitted Registration and Study Start Date (in days)",
    y = NULL
  ) +
  theme_classic(base_size = 12) +
  theme(
    plot.margin  = margin(t = 10, r = 28, b = 12, l = 28),
    axis.text.y  = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid   = element_blank(),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.justification = "center",
    legend.text = element_text(size = 8),
    legend.key.size = unit(0.4, "cm"),
    axis.text.x = element_text(margin = margin(t = 6))
  ) +
  guides(
    fill   = guide_legend(
      order = 1, nrow = 1,
      override.aes = list(colour = NA, stroke = 0)
    ),
    colour = guide_legend(
      order = 2, nrow = 1,
      override.aes = list(fill = "white", stroke = 0.9)
    )
  )

print(pB)

ggsave(file.path(filepath, "FigureB_registration_timing_with_date_first_submitted.png"),
       pB, width = 10, height = 5, dpi = 300)